from flask import Flask, request, jsonify
import joblib
import pandas as pd
import numpy as np
import os
import mysql.connector

# Load model and preprocessors with proper error handling
def load_file(file_name):
    try:
        return joblib.load(file_name)
    except FileNotFoundError:
        raise FileNotFoundError(f"File '{file_name}' not found. Ensure it exists in the correct directory.")

# Load model and preprocessors
model = load_file('random_forest_model.pkl')
scaler = load_file('scaler.pkl')
label_encoder_location = load_file('label_encoder_location.pkl')
label_encoder_device = load_file('label_encoder_device.pkl')

print("Available Location Classes:", label_encoder_location.classes_)
print("Available Device Classes:", label_encoder_device.classes_)

# Database connection
def get_db_connection():
    return mysql.connector.connect(
        host='localhost',
        user='root',
        password='Sakshi@123',
        database='UPI_Fraud_DB',
        port=3307
    )

app = Flask(__name__)

# Test Endpoint
@app.route('/', methods=['GET'])
def home():
    return 'API is running!'

# Predict Endpoint
@app.route('/predict', methods=['POST'])
def predict():
    try:
        data = request.get_json()
        if not data:
            return jsonify({'error': 'No input data provided'}), 400

        df = pd.DataFrame([data])
        required_columns = ['User_ID', 'Amount', 'Location', 'Device_Info', 'Transaction_Time']
        missing_cols = [col for col in required_columns if col not in df.columns]

        if missing_cols:
            return jsonify({'error': f'Missing columns: {missing_cols}'}), 400

        # Validate Location and Device Info
        if df['Location'].values[0] not in label_encoder_location.classes_:
            return jsonify({'error': f"Invalid Location: {df['Location'].values[0]}"}), 400

        if df['Device_Info'].values[0] not in label_encoder_device.classes_:
            return jsonify({'error': f"Invalid Device_Info: {df['Device_Info'].values[0]}"}), 400

        # Encode categorical variables
        df['Location'] = label_encoder_location.transform([df['Location'].values[0]])
        df['Device_Info'] = label_encoder_device.transform([df['Device_Info'].values[0]])

        # Preprocess and predict
        features = df.drop(columns=['Transaction_Time'])
        features_scaled = scaler.transform(features)
        prediction = model.predict(features_scaled)
        result = 'Fraud' if prediction[0] == 1 else 'Not Fraud'

        # Store in database
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute(
            "INSERT INTO Transactions (User_ID, Amount, Location, Device_Info, Transaction_Time, Prediction) VALUES (%s, %s, %s, %s, %s, %s)",
            (data['User_ID'], data['Amount'], data['Location'], data['Device_Info'], data['Transaction_Time'], result)
        )
        conn.commit()

        # Store fraud alert if fraud is detected 
        if result == 'Fraud':
            cursor.execute(
                "INSERT INTO Fraud_Alerts (User_ID, Amount, Location, Device_Info, Transaction_Time, Prediction) VALUES (%s, %s, %s, %s, %s, %s)",
                (data['User_ID'], data['Amount'], data['Location'], data['Device_Info'], data['Transaction_Time'], result)
            )
            conn.commit()

        cursor.close()
        conn.close()

        return jsonify({'prediction': result})
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
