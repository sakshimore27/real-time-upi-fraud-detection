import pandas as pd
import numpy as np
from faker import Faker
import random

# Initialize Faker to generate realistic data
fake = Faker('en_IN')

# Parameters
num_transactions = 5000
fraud_percentage = 0.1  # 10% fraud transactions

# Generate data
transactions = []
for _ in range(num_transactions):
    user_id = random.randint(1000, 9999)
    amount = round(random.uniform(10, 100000), 2)
    location = fake.city()
    device_info = random.choice(['iPhone 14', 'Samsung S23', 'OnePlus 11', 'Vivo V27'])
    transaction_time = fake.date_time_this_year()
    is_fraud = 0

    # Fraud Type 1: High Amount Fraud
    if amount > 80000 and random.random() < 0.7:
        is_fraud = 1

    # Fraud Type 2: Location-Based Fraud
    elif random.random() < 0.05 and location in ['Remote Village', 'Suspicious City']:
        is_fraud = 1

    # Fraud Type 3: Device Spoofing Fraud
    elif random.random() < 0.03 and device_info in ['Unknown Device', 'Rooted Device']:
        is_fraud = 1

    # Fraud Type 4: Multiple Rapid Transactions
    elif random.random() < 0.1 and amount < 500 and random.randint(1, 5) == 3:
        is_fraud = 1

    # Fraud Type 5: Late Night Fraud
    elif random.random() < 0.15 and transaction_time.hour in [1, 2, 3]:
        is_fraud = 1

    transactions.append([user_id, amount, location, device_info, transaction_time, is_fraud])

# Create DataFrame
df = pd.DataFrame(transactions, columns=['User_ID', 'Amount', 'Location', 'Device_Info', 'Transaction_Time', 'Is_Fraud'])

# Save to CSV
df.to_csv('simulated_upi_transactions.csv', index=False)
print('Synthetic dataset with multiple fraud types generated and saved to simulated_upi_transactions.csv')
