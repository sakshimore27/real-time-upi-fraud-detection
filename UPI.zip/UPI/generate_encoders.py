import pandas as pd
from sklearn.preprocessing import LabelEncoder
import joblib

# Load the dataset
df = pd.read_csv('simulated_upi_transactions.csv')

# Check if Location and Device_Info columns exist
if 'Location' not in df.columns or 'Device_Info' not in df.columns:
    raise ValueError("Location or Device_Info column not found in the dataset!")

# Initialize LabelEncoders
label_encoder_location = LabelEncoder()
label_encoder_device = LabelEncoder()

# Fit the encoders
label_encoder_location.fit(df['Location'])
label_encoder_device.fit(df['Device_Info'])

# Save the encoders to files
joblib.dump(label_encoder_location, 'label_encoder_location.pkl')
joblib.dump(label_encoder_device, 'label_encoder_device.pkl')

print("Encoders for Location and Device_Info have been successfully created and saved.")