import requests
import json
import time
import random
import joblib
from faker import Faker

# Initialize Faker for generating realistic data
fake = Faker()

# Load the encoders to fetch valid device names and locations
label_encoder_location = joblib.load('label_encoder_location.pkl')
label_encoder_device = joblib.load('label_encoder_device.pkl')

valid_locations = label_encoder_location.classes_
valid_devices = label_encoder_device.classes_

print("Valid Locations:", valid_locations)
print("Valid Devices:", valid_devices)

API_URL = 'http://localhost:5000/predict'

# Generate random transaction data
def generate_transaction():
    return {
        'User_ID': random.randint(1000, 9999),
        'Amount': round(random.uniform(100.0, 100000.0), 2),
        'Location': random.choice(valid_locations),
        'Device_Info': random.choice(valid_devices),
        'Transaction_Time': str(fake.date_time_this_year())
    }

# Simulate and send transactions
def simulate_transactions(n=10, delay=2):
    print("Starting transaction simulation...")
    for _ in range(n):
        transaction = generate_transaction()
        print(f"Sending Transaction: {transaction}")

        try:
            # Send transaction to the prediction API — let the API handle DB insert + prediction
            response = requests.post(API_URL, json=transaction)
            print(f"Response: {response.status_code}, {response.json()}\n")

        except Exception as e:
            print(f"Error: {e}")

        time.sleep(delay)

if __name__ == '__main__':
    simulate_transactions()
