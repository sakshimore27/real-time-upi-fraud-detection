import streamlit as st
import pandas as pd
import mysql.connector
import plotly.express as px

# -------------------------------------------
# 🛠 Database connection
def get_db_connection():
    return mysql.connector.connect(
        host='localhost',
        user='root',
        password='Sakshi@123',
        database='UPI_Fraud_DB',
        port=3307
    )

#  Fetch data
def fetch_data(query):
    try:
        conn = get_db_connection()
        df = pd.read_sql(query, conn)
        conn.close()
        return df.drop_duplicates(subset='Transaction_ID', keep='last')
    except Exception as e:
        st.error(f"Error fetching data: {e}")
        return pd.DataFrame()

#  Streamlit Layout
st.set_page_config(page_title="UPI Fraud Dashboard", layout="wide")
st.title('💸 Real-Time UPI Fraud Detection Dashboard')
st.caption(f"🕒 Last updated: {pd.Timestamp.now().strftime('%Y-%m-%d %H:%M:%S')}")

tab1, tab2 = st.tabs(["Live Transactions", "Fraud Alerts"])

#  Tab 1: Live Transactions
with tab1:
    st.subheader('📈 Live Transactions (Last 50)')
    transactions_query = "SELECT * FROM Transactions ORDER BY Transaction_ID DESC LIMIT 50"
    df_transactions = fetch_data(transactions_query)

    if 'Prediction' not in df_transactions.columns:
        df_transactions['Prediction'] = 'Unknown'
    df_transactions['Prediction'].fillna('Unknown', inplace=True)

    st.dataframe(df_transactions)

    if not df_transactions.empty:
        fig = px.scatter(df_transactions,
                         x='Transaction_Time',
                         y='Amount',
                         color='Prediction',
                         title='Transaction Amounts Over Time')
        st.plotly_chart(fig)

# 🚨 Tab 2: Fraud Alerts
with tab2:
    st.subheader('🚨 Fraud Alerts')
    fraud_query = "SELECT * FROM Fraud_Alerts ORDER BY Transaction_TIME DESC "
    df_fraud = fetch_data(fraud_query)

    if not df_fraud.empty:
        st.warning(f"⚠️ {len(df_fraud)} Fraudulent Transactions Detected")
        st.dataframe(df_fraud)

        # 🔊 Alert Sound
        alert_sound = """
        <audio autoplay>
            <source src="https://www.soundjay.com/button/beep-07.wav" type="audio/wav">
        </audio>
        """
        st.markdown(alert_sound, unsafe_allow_html=True)


#  Sidebar Filters
st.sidebar.header('🔍 Filters')
amount_filter = st.sidebar.slider('Amount Range', min_value=0, max_value=100000, value=(0, 100000))
date_filter = st.sidebar.date_input('Transaction Date', [])

if not df_transactions.empty:
    df_filtered = df_transactions[
        (df_transactions['Amount'] >= amount_filter[0]) &
        (df_transactions['Amount'] <= amount_filter[1])
    ]

    if date_filter and len(date_filter) == 2:
        start_date, end_date = pd.to_datetime(date_filter)
        df_filtered = df_filtered[
            (pd.to_datetime(df_filtered['Transaction_Time']) >= start_date) &
            (pd.to_datetime(df_filtered['Transaction_Time']) <= end_date)
        ]

    st.subheader('🔎 Filtered Transactions')
    st.dataframe(df_filtered)
