import requests

data = {
    "User_ID": 1234,
    "Amount": 85000.50,
    "Location": "Mumbai",
    "Device_Info": "iPhone 14",
    "Transaction_Time": "2025-03-23T02:30:00"
}

response = requests.post("http://127.0.0.1:5000/predict", json=data)
print(response.json())
